#=
#   @author Mateusz Laskowski
=#

################# USING POLYNOMIALS #################
# (A)
using Polynomials;
p=[1, -210.0, 20615.0,-1256850.0,
      53327946.0,-1672280820.0, 40171771630.0, -756111184500.0,          
      11310276995381.0, -135585182899530.0,
      1307535010540395.0,     -10142299865511450.0,
      63030812099294896.0,     -311333643161390640.0,
      1206647803780373360.0,     -3599979517947607200.0,
      8037811822645051776.0,      -12870931245150988800.0,
      13803759753640704000.0,      -8752948036761600000.0,
      2432902008176640000.0]

P_z = Poly(reverse(p));
p_z = poly([i for i in 1.0:20.0]);

rootP_z = reverse(roots(P_z));
println("Problem A");
for i in 1:20
    println(i);
    #println("P_z -> ", abs(polyval(P_z, rootP_z[i])));
    #println("p_z -> ", abs(polyval(p_z, rootP_z[i])));
    #println("z-k -> ", abs(i - rootP_z[i]));
end

println("Roots");
for i in 1:20
    println(rootP_z[i]);
end

# (B)
p=[1, -210.0 - 2.0^-32, 20615.0,-1256850.0,
      53327946.0,-1672280820.0, 40171771630.0, -756111184500.0,          
      11310276995381.0, -135585182899530.0,
      1307535010540395.0,     -10142299865511450.0,
      63030812099294896.0,     -311333643161390640.0,
      1206647803780373360.0,     -3599979517947607200.0,
      8037811822645051776.0,      -12870931245150988800.0,
      13803759753640704000.0,      -8752948036761600000.0,
      2432902008176640000.0]

P_z = Poly(reverse(p));
p_z = poly([i for i in 1.0:20.0]);

rootP_z = reverse(roots(P_z));
println("Problem B");
for i in 1:20
    println(i);
    println("P_z -> ", abs(polyval(P_z, rootP_z[i])));
    println("p_z -> ", abs(polyval(p_z, rootP_z[i])));
    println("z-k -> ", abs(i - rootP_z[i]));
end

println("Roots");
for i in 1:20
    println(rootP_z[i]);
end